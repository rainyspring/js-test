alert("hello,world a.js");
$("")